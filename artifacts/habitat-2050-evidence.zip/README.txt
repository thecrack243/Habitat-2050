Habitat 2050 | Educational competition demonstration
One fixed training-only random forest; preliminary random holdout validation.
Relative suitability is not occupancy probability. Background is not verified absence.
Current climate: 1970-2000. Future: SSP2-4.5, MPI-ESM1-2-HR, 2041-2060.
Vegetation is held static. No dispersal or population projection.
See evaluation.json for parameters, versions, hashes, threshold, and limitations.
GeoJSON coordinates are longitude/latitude (WGS84); areas use WGS84 ellipsoid integration.
Not for conservation planning, land use, or policy decisions.
